function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5uOBTcOy6dz":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

